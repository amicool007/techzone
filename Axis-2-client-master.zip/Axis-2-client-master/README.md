Axis-2-client
=============

"In this tutorial we are going to code an axis 2 client based on wsdl2java approach." This is a tutorial material. For more great tutorials visit us on itcuties.com.
